// Variables
//let name = "Peter";
//let age = 5;
//console.log("Hi, my name is " + name);
//console.log("I am " + age + "years old.");

//Loops
//for (let i = 0; i <10; i++)
//{
//   if (i % 2 == 1)
//    {
//        console.log(i);
//    }

//}

// Creating Arrays
//const myArr = ["I Love RP!", true];

//console.log(myArr[0]);
//console.log(myArr[1]);

// Accessing Array elements
const myArr = ["I Love RP!", true, 5];

for (let i = 0; i < myArr.length; i++)
{
    console.log(myArr[1]); 
}


