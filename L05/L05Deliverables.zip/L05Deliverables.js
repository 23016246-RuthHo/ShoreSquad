//Q1
let studentName = "Ruth";
let studentAge = 19;
console.log("Hi, my name is " + studentName + "and I am" + studentAge +" years old.");

//Q2
let moduleCode = "C237";
console.log("Ï am learning module" + moduleCode + "this semester.")

//Q3
for (let i = 1; i <=5; i++)
{
    console.log(i);
}

//Q4
for (let i = 1; i <=10; i++)
{
    if (i % 2 == 0)
    {
        console.log(i);
    }
}

//Q5
let favThings = ["Coding", "Music", "Cats"];
console.log(favThings[0]);
console.log(favThings[1]);
console.log(favThings[2]);

//Q6
for (let i = 0; i < favThings.length; i++)
{
    console.log(favThings[i]);
}
